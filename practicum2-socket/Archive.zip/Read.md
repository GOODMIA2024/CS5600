Self-Evaluation Link -
https://northeastern-my.sharepoint.com/:x:/g/personal/tao_mi_northeastern_edu/ESnfpEeYjZlCrxwP1gMpyC8BABNPjmNpFq6OsEbvywmwNg?e=KFpLgs

2. Assume the root folder in the remote file system is var/rfs

TEST WRITE Command
- data/localfoo.txt already exists
local file is in <local>
./rfs WRITE local/localfoo.txt remote/foo.txt


TEST RM Command
./rfs RM folder/somefile.txt

TEST GET Command
./rfs GET var/foo25.txt local/copy1.txt